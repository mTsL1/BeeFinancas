# bee/academy/__init__.py
# Bee Academy package
